##Tri des données des logs
#MICHAUD Simon - RIOU Hugo
#05/01/2023
#Version 1
#Visual Studio Code 1.74.3 - Python 3.11.1


date = input("Saisissez une date par prompt : ") #saisie de la date par l'utilisateur pour déterminer le fichier à ouvrir

f = open('log_proxy_'+date+'.txt','r') #ouverture du fichier texte (lecture)
z = open('loginfo.csv','w') #ouverture du fichier csv (écriture)

z.write('date;heure;adresseIP;urlVisite \n') #noms des colonnes

for line in f: #pour chaque ligne du fichier log
    t = line.split(' ')
    z.write(date + ';' + t[0] + ';' + t[1] + ';' + t[4] + '\n') #ajout des données pertinentes 