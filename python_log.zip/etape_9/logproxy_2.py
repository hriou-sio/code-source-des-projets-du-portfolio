##logproxy_2
#ce programme lit les fichiers du dossier log situé en sous repertoire du chemin courant et génère des requètes SQL

import os
from os import chdir

chdir("log") #change de dossier et se positionne dans le dossier log
files = os.listdir('.') #liste les fichiers contenu dans le dossier

for name in files:
	f = open(name,'r') #ouverture du fichier texte
	n = name.split('_')
	n2 = n[2].split('.')
	z = open('insert_'+n2[0]+'.sql','w') #ouverture du fichier sql

	for line in f: #pour chaque ligne du fichier log
		t = line.split(' ')
		#ajout de la commande sql
		z.write('INSERT INTO \n' + 'PROXY(ID,adresseip,jourheure,URL) \n' + "VALUES(NULL,'" + t[1] + "','" + t[0] + "','" +  t[4] + "'); \n")

print("Les ordres SQL ont été transféré avec succès dans les fichiers.") #affichage du résultat
