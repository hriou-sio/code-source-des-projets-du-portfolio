##Création d'indentifiant
#MICHAUD Simon - RIOU Hugo
#04/01/2023
#Version 1 
#Python 3.11.1


f = open("testEntree.txt","r") #ouvre le fichier en lecture
z = open("testSortie.txt","w") #ouvre le fichier en écriture


for line in f: #pour chaque ligne du fichier
    t = line.split(";") #divise le prénom du nom en fonction du ;
    mot = (t[0] [0] + t[1]) #assigne à mot la premier lettre du prénom et le nom
    mot = mot.lower() #converti la chaine obtenue en minuscule
    z.write(str(mot) + '\n') #ajoute mot au fichier z en revenant à la ligne

z.close() #fermeture du fichier z
f.close() #fermeture du fichier f
    
