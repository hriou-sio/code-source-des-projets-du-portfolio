import os

date = str(input("Saisissez une date par prompt (XXXX-XX-XX) : ")) #saisie de la date par l'utilisateur pour déterminer le fichier à ouvrir

#contrôle de saisie (fichier vide ou introuvable)
while (os.path.isfile('log_proxy_'+date+'.txt') == False) or (os.path.getsize('log_proxy_'+date+'.txt') == 0):
	date = str(input("Désolé, ce fichier n'existe pas ou est vide. Veuillez entrer une date par prompt (XXXX-XX-XX) correspondant à un fichier valide: "))

f = open('log_proxy_'+date+'.txt','r') #ouverture du fichier texte
z = open('insert_'+date+'.sql','w') #ouverture du fichier sql

for line in f: #pour chaque ligne du fichier log
	t = line.split(' ')
	#ajout de la commande sql
	z.write('INSERT INTO \n' + 'PROXY(ID,adresseip,jourheure,URL) \n' + "VALUES(NULL,'" + t[1] + "','" + date + ' / ' + t[0] + "','" +  t[4] + "'); \n")

print("L'ordre SQL a été transféré avec succès dans le fichier", 'insert_'+date+'.sql.') #affichage du résultat
