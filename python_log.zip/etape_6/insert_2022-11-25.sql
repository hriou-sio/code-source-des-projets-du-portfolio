INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:20','http://materiel.net/'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:21','http://www.materiel.net/'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://media.materiel.net/js/jquery/lib/matnet.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://media.materiel.net/js/jquery/themes/matnet/matnet.css?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://media.materiel.net/js/tools.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://www.materiel.net/js/jquery/plugins/uberbanner/uberbanner.css?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://media.materiel.net/js/jquery/plugins/uberbanner/uberbanner.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://media.materiel.net/js/site.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:22','http://media.materiel.net/js/swfobject/swfobject.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://media.materiel.net/css/main-1389077881.css'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://media.materiel.net/js/jquery/lib/jquery.min.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://media.materiel.net/js/jquery/lib/jquery-ui.min.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://media.materiel.net/js/basket.js?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://www.materiel.net/assets/10542.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://www.materiel.net/assets/6795.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:23','http://www.materiel.net/assets/14093.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97761.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/181132.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97759.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/187996.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97760.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://www.materiel.net/assets/10540.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/css/main/header-background.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97762.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97763.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97765.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97764.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97766.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:24','http://media.materiel.net/live/97767.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/97768.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/97769.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/215887.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/97770.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/97772.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/97771.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/106422.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://www.google-analytics.com/__utm.gif?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/live/215888.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/home-section-3col-background.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/home-section-2col-background.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/social-facebook-58x58.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/social-twitter-58x58.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/home-badges.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/footer-pattern.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/aside-sprites.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/home-box-headers_2.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/footer-top-header.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/footer-separator.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/footer-buttons.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/social-footer-facebook.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/footer-background.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:25','http://media.materiel.net/css/main/social-footer-twitter.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/assets/?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/live/245732.106.106.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/live/245143.106.106.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/live/245881.106.106.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/live/244913.106.106.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/live/245802.106.106.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:26','http://www.materiel.net/live/245760.106.106.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:27','http://www.materiel.net/live/245733.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:27','http://www.materiel.net/assets/14391.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:27','http://www.materiel.net/live/245259.106.106.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:27','http://www.materiel.net/live/245043.106.106.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:28','http://www.materiel.net/favicon.ico'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:28','http://js-agent.newrelic.com/nr-100.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:29','http://beacon-2.newrelic.com/1/9bfaac61cd?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:32','http://www.materiel.net/live/245044.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:33','http://www.materiel.net/assets/14339.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:37','http://www.materiel.net/live/245532.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:37','http://www.materiel.net/assets/14364.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:43','http://www.materiel.net/assets/14353.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:46','http://www.materiel.net/live/245882.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:47','http://www.materiel.net/assets/14403.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:52','http://www.materiel.net/live/244914.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:53','http://www.materiel.net/assets/14327.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:57','http://www.materiel.net/assets/14381.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:42:57','http://www.materiel.net/live/245803.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:02','http://www.materiel.net/live/245761.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:04','http://www.materiel.net/assets/14389.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:09','http://www.samba.org/'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:12','http://www.samba.org/samba/what_is_samba.html'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:17','http://images.pearsoned-ema.com/jpeg/small/0131453556.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:17','http://images.pearsoned-ema.com/jpeg/small/0131472216.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:17','http://images.pearsoned-ema.com/jpeg/small/9780131472211.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:17','http://images.pearsoned-ema.com/jpeg/small/9780131453555.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:21','http://www.samba.org/samba/team/'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.1','2022-11-25 / 11:43:22','http://www.samba.org/samba/images/team2011-IMG_5607.JPG'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:16','http://www.editions-eni.fr/'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/Styles/fontface/fonts.css'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/scripts/jquery.ellipsis.min.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/css/bundle_B38B6395F5BD52630735B999C665EB97.css'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/scripts/bundle_7E80699C53C26363A6BB41EA7924AA6E.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/scripts/jquery-1.10.2.min.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/images/trw/tC.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/styles/france/images/logo_ENI.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-tableaux-de-synthese-et-tableaux-de-bord-traitez-et-analysez-de-gros-volumes-de-donnees-avec-excel/.7483deeff62371a848d989cdb0388cd3.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/WebResource.axd?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-audit-de-site-web/.3bd20b66a0c506853f6e12de911e78b3.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-linux-administration-avancee-maintenance-et-exploitation-de-vos-serveurs/.fe85e09a31665a5d4fccd5280f8fccda.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-internal-hacking-et-contre-mesures-en-environnement-windows-piratage-interne-mesures-de-protection-developpement-d-outils/.aa224e10d72749297942ef578e38c5a1.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-hacking-un-labo-virtuel-pour-auditer-et-mettre-en-place-des-contre-mesures/.a45802cae809cedf7bba1b5151787ca5.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-windows-powershell-version-3-guide-de-reference-pour-l-administration-systeme/.a4e175a05aab4e722cce308777665d48.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-formation-excel-2013-toutes-les-fonctionnalites-d-excel-a-votre-portee-le-livre-numerique-excel-2013-offert-valable-1-an-a-volonte/.49acc40eaccc9a2ae5340b06bb4d062e.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-formation-excel-2013-maitrisez-les-bases-essentielles-valable-1-an-a-volonte/.0a198a37c3ab82723e1103dcb4f43703.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-mcsa-windows-server-2012-coffret-de-3-livres-preparation-aux-examens-70-410-70-411-70-412-et-70-417/.0c9180d77165718cede9546cf8abcc3f.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-formation-excel-2013-devenez-utilisateur-confirme-valable-1-an-a-volonte/.cd408e0296bd88eb81dadd55038824d8.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-vba-access-2013-cours-et-exercices-corriges-creez-des-applications-professionnelles/.46d53ec3169ea195a7c33accaeffb4dd.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:17','http://www.editions-eni.fr/livres-c-5-developpez-des-applications-windows-avec-visual-studio-2013/.e660acd70e0504226e2020eddcef6f12.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/livres-excel-2013/.837ab0c2a42fc30712b4765b16a493af.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/images/Security.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/livres-support-de-windows-8-1-preparation-a-la-certification-mcsa-examen-70-688/.e5033184ac560d00bc07ce6ddb9b2236.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/include/xtclicks.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/styles/france/images/bg_Header.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/styles/france/images/shdw_SpaceItem_B.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/images/DownArrow.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/images/drapeauFr.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/images/drapeauES.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/styles/france/images/shdw_SpaceItem_R.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://static.criteo.net/js/ld/ld.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/images/drapeauUK.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/images/drapeauGE.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/_staticpages/e85d489c-b9f4-4e9b-95fe-069e90892383'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:18','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/images/Home_List_BG.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/images/Home_BestSales_ico.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/images/sprite_icos.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/Espaces/Espace_d9bd8b5e-f324-473f-b1fc-b41b421c950f/images/Home_NewProducts_ico.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/images/shdw_Various_B.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/images/ico_Search.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/images/ico_Basket.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/favicon.ico'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.google-analytics.com/__utm.gif?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/styles/france/xtcore.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://widget.criteo.com/event?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://logi7.xiti.com/hit.xiti?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:19','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/style.css'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/js/jquery.ui.touch-punch.min.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/js/allinone_contentSliderV2.js'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/btnEnsavoirplus4.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/btnEnsavoirplus3.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/btnEnsavoirplus2.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/SOB13EXCTAB.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/EILINAA.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:20','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/OWWEBAUD.jpg'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/_staticpages/e85d489c-b9f4-4e9b-95fe-069e90892383/images/fond1.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/images/espaceur.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/skins/hand.cur'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/skins/rightNavOFF.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/skins/leftNavOFF.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/skins/bottomNavOFF.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:21','http://www.editions-eni.fr/%5Fstaticpages/e85d489c%2Db9f4%2D4e9b%2D95fe%2D069e90892383/skins/bottomNavON.png'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:22','http://dis.eu.criteo.com/dis/dis.aspx?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:22','http://cm.g.doubleclick.net/pixel?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://ib.adnxs.com/seg?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://pixel.rubiconproject.com/tap.php?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://rfr.a2dfp.net/r?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://view.atdmt.com/action/EU_Criteo_FR_300x250_OandO_pop_Sep13'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://ad.prismamediadigital.com/track/compginc2.asp?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://tag.bubblestat.com/tag.bub?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://ad.prismamediadigital.com/track/compginc2.asp?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://www2.adserverpub.com/setc.php?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://r.ad6media.fr/r.php?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:23','http://ads.lfstmedia.com/mark/105169_1?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://securite.01net.com/track/comp.asp?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://www3.smartadserver.com/track/comp.asp?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://ad.prismamediadigital.com/track/compginc2.asp?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://ib.adnxs.com/seg?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://pixel.rubiconproject.com/tap.php?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://rfr.a2dfp.net/r?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://tag.bubblestat.com/tag.bub?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://view.atdmt.com/action/EU_Criteo_FR_300x250_3P_pop_Sep13'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:24','http://ib.adnxs.com/seg?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:25','http://oas.rcsadv.it/RealMedia/ads/adstream.cap/123?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:25','http://ib.adnxs.com/getuid?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:25','http://tag.bubblestat.com/tag.bub?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:25','http://oas.rcsadv.it/RealMedia/ads/Creatives/default/empty.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:28','http://ads.horyzon-media.com/diffx/track/compgb.ashx?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:28','http://dis.criteo.com/dis/rtb/google/cookiematch.aspx?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:29','http://r.ad6media.fr/c3/s'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:29','http://banner.adserverpub.com/spacer.gif'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:29','http://dis.criteo.com/dis/rtb/appnexus/cookiematch.aspx?'); 
INSERT INTO 
PROXY(ID,adresseip,jourheure,URL) 
VALUES(NULL,'192.168.2.100','2022-11-25 / 12:04:29','http://static.eu.criteo.net/empty.html'); 
