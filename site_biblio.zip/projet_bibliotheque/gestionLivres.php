<?php session_start();
include 'connexion.php';?>
<head class="topmenu">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Ubuntu:wght@300&display=swap"
    rel="stylesheet">
  <title>Bibliothèque</title>
</head>

<body>
  <header class="topmenu"></header>
  <style>
  </style>
  <ul class="menu">
    <li>
      <a href="index.html"><span>Accueil</span></a>
    </li>
    <li>
      <a href="info.html">Information</a>
    </li>
    <li>
      <a href="livres.php">Livres</a>
    </li>
    <li>
      <a href="contact.html">Contact</a>
    </li>
    <li>
      <a href="gestionLivres.php">Gestion</a>
    </li>
  </ul>
  </header>
  <div id="Livres">
      
    <h1>Gestion des livres</h1>
  </div>
  <div>
	<form action="gestionLivre_2.php" method="get">
	<fieldset>
	Choisissez un livre : 
	<select name="listeCat">
            <?php
            $reponse = $connexion->query('SELECT * FROM livre');
            while ($donnees=$reponse->fetch())
            {?>
            <option value = "<?php echo $donnees["ref"] ?>"><?php echo $donnees["titre"] ?></option>
            <?php
            }
            $connexion=null;
            ?>
	</select>
	</fieldset>
        <br>
	<input type="submit" value="Modifier" />
	<input type="submit" value="Supprimer" />
	</form>
  </div> <br>
    
    <h2>Ajout d'un livre</h2>
  </div>
 <form action="ajoutLivres.php" method="POST">
    <input type="text" name="titreN" placeholder="Titre du livre" /><br />
    <input type="text" name="auteurN" placeholder="Auteur" /><br />
    <input type="text" name="langueN" placeholder="Langue" /><br />
    <input type="text" name="anneeN" placeholder="Annee"  /><br />
    <input type="text" name="isbnN" placeholder="ISBN"  /><br />
    <input type="text" name="idcatN" placeholder="ID de la catégorie"  /><br />
    <input type="text" name="refN" placeholder="Référence du livre"  /><br /><br />
    <input type="submit" value="Ajouter" />
</form>
</body>
<footer>
  <br>
  <a href="https://www.linternaute.fr"></a>
  <br>

  <aside><a href="https://www.la-joliverie.com/"><img src="logo_joliverie_hd_cmjn_png.png" alt=""></a></aside>
  <hr>
  <p>Copyright © 2023 Simon - Hugo. All rights reserved</p>
  <hr>
</footer>
