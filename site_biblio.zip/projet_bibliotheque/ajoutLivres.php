<?php
include ("connexion.php");
session_start(); ?>

<head class="topmenu">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Ubuntu:wght@300&display=swap"
    rel="stylesheet">
  <title>Bibliothèque</title>
</head>

<body>
  <header class="topmenu"></header>
  <style>
  </style>
  <ul class="menu">
    <li>
      <a href="index.html"><span>Accueil</span></a>
    </li>
    <li>
      <a href="info.html">Information</a>
    </li>
    <li>
      <a href="livres.php">Livres</a>
    </li>
    <li>
      <a href="contact.html">Contact</a>
    </li>
    <li>
      <a href="gestionLivres.php">Gestion</a>
    </li>
  </ul>
  </header>
  <div id="Livres">
    <h2>Ajout d'un livre</h2>
  </div>
 <?php

if (isset($_POST["titreN"]) && isset($_POST["auteurN"]) && isset($_POST["langueN"]) && isset($_POST["anneeN"]) && isset($_POST["isbnN"]) && isset($_POST["idcatN"])) {
// Si la saisie a été effectuée
if ($_POST["titreN"] != "" && $_POST["auteurN"] != "" && $_POST["langueN"] != "" && $_POST["anneeN"] != "" && $_POST["isbnN"] != "" && $_POST["idcatN"] != "") {
// Si tous les champs sont renseignés
$titreN = $_POST["titreN"];
$auteurN = $_POST["auteurN"];
$langueN = $_POST["langueN"];
$anneeN = $_POST["anneeN"];
$isbnN = $_POST["isbnN"];
$idcatN = $_POST["idcatN"];
$refN = $_POST["refN"];

//on insère dans la bdd 
//utilisation d'une requete préparée par mesure de sécurité
//$requete = 'INSERT INTO utilisateur (nom, prenom, email, mdp) VALUES ("' . $nomU . '","' . $prenomU . '","' . $mailU . '","' . $mdpU . '")';
//$ok = $connexion->exec($requete);
 $requete = "INSERT INTO livre (ref, isbn, titre, auteur, langue, annee, id_cat) VALUES (:refN,:isbnN,:titreN,:auteurN,:langueN,:anneeN,:idcatN)";
  $req = $connexion->prepare($requete);
  $req->bindValue(':refN', $refN);
  $req->bindValue(':isbnN',$isbnN);
  $req->bindValue(':titreN',$titreN);
  $req->bindValue(':auteurN', $auteurN);
  $req->bindValue(':langueN', $langueN);
  $req->bindValue(':anneeN', $anneeN);
  $req->bindValue(':idcatN', $idcatN);
  $ok=$req->execute(); 
if ($ok){
echo ("Votre livre a bien été ajouté !");

}
?>
<p><a href="gestionLivres.php">Gestion des livres</a></p>
<?php

} else {
echo("Erreur lors de l'ajout du livre.");
}
}?>
</body>
<footer>
  <br>
  <a href="https://www.linternaute.fr"></a>
  <br>

  <aside><a href="https://www.la-joliverie.com/"><img src="logo_joliverie_hd_cmjn_png.png" alt=""></a></aside>
  <hr>
  <p>Copyright © 2023 Simon - Hugo. All rights reserved</p>
  <hr>
</footer>