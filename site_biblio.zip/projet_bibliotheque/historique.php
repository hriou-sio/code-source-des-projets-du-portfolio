<!DOCTYPE html>
<?php
include("connexion.php");
session_start();
?>

<head class="topmenu">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Ubuntu:wght@300&display=swap"
    rel="stylesheet">
  <title>Bibliothèque</title>
</head>

<body>
  <header class="topmenu"></header>
  <style>
  </style>
  <ul class="menu">
    <li>
      <a href="index.html"><span>Accueil</span></a>
    </li>
    <li>
      <a href="info.html">Information</a>
    </li>
    <li>
      <a href="livres.php">Livres</a>
    </li>
    <li>
      <a href="contact.html">Contact</a>
    </li>
    <li>
      <a href="gestionLivres.php">Gestion</a>
    </li>
  </ul>
  </header>
  <div id="Livres">
    <h2>Historique d'emprunts</h2>
  </div>
  <div>
        <meta charset="utf-8" />
        <title>Historique des emprunts:</title>
  </div>
  <div>
	<?php
        $reponse = $connexion->query('SELECT * FROM emprunt');
        $i = 0;
        while ($donnees=$reponse->fetch())
        {
            if ($_SESSION['ref'] == $donnees['ref']){
                ?><span>date d'emprunt : </span><?php echo $donnees['date_deb'].'<br />';
                ?><span>date de rendu : </span><?php echo $donnees['date_fin'].'<br />';
                $i = 1;
            }
        }
        if ($i == 0){
            echo "Aucun emprunt pour ce livre.";
        }
        
        
        $connexion=null;
        ?>
  </div>
  
</body>
<footer>
  <br>
  <a href="https://www.linternaute.fr"></a>
  <br>

  <aside><a href="https://www.la-joliverie.com/"><img src="logo_joliverie_hd_cmjn_png.png" alt=""></a></aside>
  <hr>
  <p>Copyright © 2023 Simon - Hugo. All rights reserved</p>
  <hr>
</footer>