<?php
try {
$db = "hriou_biblio";
$dbhost="10.15.253.250";
$dbport=3306; //MariaDB
$dbuser="hriou";
$dbpasswd="1hD*39V@22";
$connexion = new PDO('mysql:host='.$dbhost.';port='.$dbport.';dbname='.$db.'', $dbuser, $dbpasswd);
$connexion->exec("SET CHARACTER SET utf8");
}

catch(PDOException $e){
  echo 'erreur: '.$e->getMessage();
}