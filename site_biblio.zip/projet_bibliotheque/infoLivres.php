<!DOCTYPE html>
<?php
include("connexion.php"); 
session_start();
?>

<head class="topmenu">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Ubuntu:wght@300&display=swap"
    rel="stylesheet">
  <title>Bibliothèque</title>
</head>

<body>
  <header class="topmenu"></header>
  <style>
  </style>
  <ul class="menu">
    <li>
      <a href="index.html"><span>Accueil</span></a>
    </li>
    <li>
      <a href="info.html">Information</a>
    </li>
    <li>
      <a href="livres.php">Livres</a>
    </li>
    <li>
      <a href="contact.html">Contact</a>
    </li>
    <li>
      <a href="gestionLivres.php">Gestion</a>
    </li>
  </ul>
  </header>
  <div id="Livres">
    <h2>Information sur les livres</h2>
  </div>
<html>
<head>
        <meta charset="utf-8" />
        <title>affichage des informations</title>
</head>
 <body>
 
<?php

$reponse = $connexion->query('SELECT * FROM livre');
$id= $_GET['listeCat'];
while ($donnees=$reponse->fetch())
{
    if ($id == $donnees['id_cat']){
    
    ?><img class="equipe" src="img/<?php echo $donnees['titre']?>.jpg" alt="livre"> <br>
    <span>titre : </span><?php echo $donnees['titre'].'<br />';
    ?><span>auteur : </span><?php echo $donnees['auteur'].'<br />';
    ?><span>langue : </span><?php echo $donnees['langue'].'<br />';
    ?><span>annee : </span><?php echo $donnees['annee'].'<br />';
    ?><span>ISBN : </span><?php echo $donnees['isbn'].'<br />';
    $_SESSION['ref']=$donnees['ref'];
    ?>
    <a href="historique.php">Historique d'emprunt</a> <br>
    <?php
}}
$connexion=null;
?>
    

</body>
<footer>
  <br>
  <a href="https://www.linternaute.fr"></a>
  <br>

  <aside><a href="https://www.la-joliverie.com/"><img src="logo_joliverie_hd_cmjn_png.png" alt=""></a></aside>
  <hr>
  <p>Copyright © 2023 Simon - Hugo. All rights reserved</p>
  <hr>
</footer>