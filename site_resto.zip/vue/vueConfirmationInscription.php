<?php
/**
 * --------------
 * vueConfirmationInscription
 * --------------
 */
?>
<h1>Inscription</h1>

Inscription effectuée.<br />
Veuillez vous <a href=./?action=connexion>connecter</a>.