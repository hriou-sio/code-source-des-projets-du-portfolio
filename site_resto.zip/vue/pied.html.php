<html>
    <body>
        
        <div id="signature">
            <span class='maj'>Mise à jour effectuée par l'équipe I<span>
        </div>
    </body> 
</html>
